<!-- =============================================================
     PASO 4: Vista de pie de página reutilizable
     ============================================================= -->

</div><!-- /container -->

<footer class="bg-dark text-white text-center py-3 mt-5">
    <p class="mb-0 small">
        <!-- TODO 10: Completa el pie de página con las 3 constantes.
             Resultado esperado: "© 2026 — Recetas de Mamá por Juan Pérez"
             Las constantes son: BLOG_ANIO, BLOG_TITULO, BLOG_AUTOR -->
        &copy; <?= BLOG_ANIO ?> &mdash; <?= BLOG_TITULO ?> por <?= BLOG_AUTOR ?>
    </p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
