<!-- =============================================================
     PASO 3: Vista de cabecera reutilizable
     =============================================================
     Este archivo es incluido al inicio de TODAS las páginas.
     Asume que:
       - La constante BLOG_TITULO está definida (viene de config/app.php)
       - La variable $titulo está definida en la página que hace el include
     ============================================================= -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- TODO 8: El <title> debe combinar $titulo y BLOG_TITULO separados por ' | '
         Si $titulo = 'Todas las recetas' y BLOG_TITULO = 'Recetas de Mamá'
         el resultado debe ser: "Todas las recetas | Recetas de Mamá"
         Usa el operador ?? para que si $titulo no está definido use 'Inicio'. -->
    <title><?= ($titulo ?? 'Inicio') . ' | ' . BLOG_TITULO ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark shadow mb-4">
    <div class="container">
        <!-- TODO 9: Muestra BLOG_TITULO como el texto del enlace del navbar -->
        <a class="navbar-brand fw-bold" href="index.php"><?= BLOG_TITULO ?></a>
        <a href="index.php" class="btn btn-sm btn-outline-light">
            <i class="fas fa-home me-1"></i>Inicio
        </a>
    </div>
</nav>

<div class="container py-2">
