<?php
// =============================================================
// PASO 5: Página principal — lista de recetas
// =============================================================

// ── 1. Carga de dependencias ──────────────────────────────────

require_once __DIR__ . '/config/app.php';

require_once __DIR__ . '/lib/helpers.php';

// ── 2. Datos ──────────────────────────────────────────────────
$titulo = 'Todas las recetas';

$recetas = [
    [
        'id'          => 'arroz-leche',
        'nombre'      => 'Arroz con leche',
        'categoria'   => 'Postres',
        'fecha'       => '2026-03-15',
        'descripcion' => 'Un postre clásico cremoso con leche, arroz, canela y azúcar morena.',
    ],
    [
        'id'          => 'ajiaco',
        'nombre'      => 'Ajiaco bogotano',
        'categoria'   => 'Sopas',
        'fecha'       => '2026-03-20',
        'descripcion' => 'Sopa tradicional colombiana con tres tipos de papas y pollo.',
    ],
    [
        'id'          => 'bandeja-paisa',
        'nombre'      => 'Bandeja paisa',
        'categoria'   => 'Platos fuertes',
        'fecha'       => '2026-04-01',
        'descripcion' => 'El plato insignia de la región antioqueña, completo y contundente.',
    ],
    [
        'id'          => 'empanadas',
        'nombre'      => 'Empanadas de pipián',
        'categoria'   => 'Snacks',
        'fecha'       => '2026-04-03',
        'descripcion' => 'Empanadas fritas rellenas de papa y maíz, con salsa de maní.',
    ],
];

include __DIR__ . '/vistas/header.php';
?>

<h1 class="mb-4"><?= esc($titulo) ?></h1>

<div class="row g-4">
<?php foreach ($recetas as $receta): ?>
    <div class="col-md-6">
        <div class="card shadow-sm h-100">
            <div class="card-body">

                <span class="badge bg-secondary mb-2">
                    <?= esc($receta['categoria']) ?>
                </span>

                <h5 class="card-title">
                    <?= esc($receta['nombre']) ?>
                </h5>

                <p class="card-text text-muted small">
                    <?= extracto($receta['descripcion'], 80) ?>
                </p>

                <div class="d-flex justify-content-between align-items-center mt-3">
                    <small class="text-muted">
                        <i class="fas fa-calendar me-1"></i>
                        <?= formatearFecha($receta['fecha']) ?>
                    </small>
                    <a href="receta.php?id=<?= esc($receta['id']) ?>" class="btn btn-sm btn-primary">
                        Ver receta
                    </a>
                </div>

            </div>
        </div>
    </div>
<?php endforeach; ?>
</div>

<?php
include __DIR__ . '/vistas/footer.php';
?>
