<?php
// =============================================================
// PASO 2: Librería de funciones reutilizables
// =============================================================
// Este archivo será cargado con require_once.
// No uses include aquí — si se carga dos veces sin _once
// PHP lanzaría "Fatal Error: Cannot redeclare ...".
// =============================================================

/**
 * TODO 5: esc() — Escapar texto para mostrar en HTML de forma segura.
 *
 * Recibe un string y devuelve la versión segura para HTML.
 * Convierte caracteres como <, >, &, " y ' en entidades HTML.
 *
 * Función a usar: htmlspecialchars($texto, ENT_QUOTES, 'UTF-8')
 *
 * Ejemplo:
 *   esc('<b>Hola</b>')  →  '&lt;b&gt;Hola&lt;/b&gt;'
 */
function esc(string $texto): string
{
    return htmlspecialchars($texto, ENT_QUOTES, 'UTF-8');
}

/**
 * TODO 6: formatearFecha() — Convertir fecha de YYYY-MM-DD a "D de MES de YYYY".
 *
 * Recibe una fecha en formato 'YYYY-MM-DD' y la devuelve formateada en español.
 *
 * Pista: usa strtotime() para convertir la cadena a timestamp,
 * luego date('j') para el día y date('n') para obtener el número del mes
 * (1-12) y úsalo como índice en el array $meses.
 *
 * Ejemplo:
 *   formatearFecha('2026-04-06')  →  '6 de abril de 2026'
 */
function formatearFecha(string $fecha): string
{
    $meses = [
        'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
        'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
    ];

    $timestamp = strtotime($fecha);
    $dia = date('j', $timestamp);
    $mes = $meses[(int) date('n', $timestamp) - 1];
    $anio = date('Y', $timestamp);

    return $dia . ' de ' . $mes . ' de ' . $anio;
}

/**
 * TODO 7: extracto() — Recortar texto largo y agregar '...' al final.
 *
 * Si $texto tiene más de $max caracteres, devuelve los primeros $max
 * caracteres seguidos de '...'.
 * Si $texto es igual o menor a $max, lo devuelve sin cambios.
 *
 * Funciones útiles: strlen(), substr()
 *
 * Ejemplos:
 *   extracto('Texto muy largo para mostrar', 10)  →  'Texto muy ...'
 *   extracto('Corto', 100)                         →  'Corto'
 */
function extracto(string $texto, int $max = 100): string
{
    if (strlen($texto) > $max) {
        return substr($texto, 0, $max) . '...';
    }

    return $texto;
}
