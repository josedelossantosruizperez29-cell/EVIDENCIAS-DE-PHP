<?php
// ══════════════════════════════════════════════════════
// DEMO 4: require_once vs require — problema del doble include
// Muestra la diferencia entre cargar un archivo dos veces
// con require (error) vs require_once (seguro).
// ══════════════════════════════════════════════════════

ini_set('display_errors', '1');
error_reporting(E_ALL);

$titulo = 'Demo — require_once';

include __DIR__ . '/vistas/header.php';
?>

<div class="card shadow-sm p-4 mb-4 border-0" style="border-radius:15px">
    <h2 class="mb-3">
        <span class="badge bg-success">_once</span>
        Demo: <code>require_once</code> evita redefiniciones
    </h2>

    <!-- ── Parte 1: El problema ── -->
    <h4 class="mt-3 text-danger"><i class="fas fa-bug me-2"></i>Parte 1: El problema con <code>require</code> doble</h4>
    <p>Si intentaras cargar <code>lib/helpers.php</code> dos veces con <code>require</code>, PHP fallaría al
    intentar redefinir las funciones. Este sería el código problemático:</p>
    <pre class="bg-dark text-danger p-3 rounded"><code>require __DIR__ . '/lib/helpers.php'; // ✓ OK - primera vez
require __DIR__ . '/lib/helpers.php'; // ✗ Fatal Error: Cannot redeclare limpiar()</code></pre>

    <hr>

    <!-- ── Parte 2: La solución ── -->
    <h4 class="mt-4 text-success"><i class="fas fa-check-circle me-2"></i>Parte 2: Solución con <code>require_once</code></h4>
    <p>Con <code>require_once</code>, PHP lleva un registro interno de los archivos ya cargados y omite las cargas repetidas.</p>

<?php
// Primera carga: PHP ejecuta el archivo
require_once __DIR__ . '/lib/helpers.php';

echo '<div class="alert alert-success">✓ Primera carga de <code>helpers.php</code> — funciones disponibles.</div>';

// Segunda carga: PHP detecta que ya fue cargado y lo omite silenciosamente
require_once __DIR__ . '/lib/helpers.php';

echo '<div class="alert alert-info">✓ Segunda carga de <code>helpers.php</code> con <code>require_once</code> — omitida silenciosamente. ¡Sin error!</div>';
?>

    <hr>

    <!-- ── Parte 3: Uso de las funciones ── -->
    <h4 class="mt-4"><i class="fas fa-play me-2"></i>Parte 3: Funciones cargadas y funcionando</h4>
    <p>Las funciones de <code>helpers.php</code> están disponibles:</p>

    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>Llamada</th>
                <th>Resultado</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><code>limpiar('  &lt;b&gt;Hola&lt;/b&gt;  ')</code></td>
                <td><code><?= limpiar('  <b>Hola</b>  ') ?></code></td>
            </tr>
            <tr>
                <td><code>formatearFecha('2026-04-06')</code></td>
                <td><code><?= formatearFecha('2026-04-06') ?></code></td>
            </tr>
            <tr>
                <td><code>saludar('Estudiante')</code></td>
                <td><code><?= saludar('Estudiante') ?></code></td>
            </tr>
        </tbody>
    </table>

    <h5 class="mt-4">Código de este ejemplo</h5>
    <pre class="bg-dark text-light p-3 rounded"><code>&lt;?php
require_once __DIR__ . '/lib/helpers.php'; // Carga 1 ✓
require_once __DIR__ . '/lib/helpers.php'; // Carga 2 → omitida ✓

echo limpiar('  &lt;b&gt;Hola&lt;/b&gt;  ');
echo formatearFecha('2026-04-06');
echo saludar('Estudiante');
?&gt;</code></pre>
</div>

<?php include __DIR__ . '/vistas/footer.php'; ?>
