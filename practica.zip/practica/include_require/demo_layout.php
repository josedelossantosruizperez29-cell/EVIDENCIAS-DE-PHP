<?php
// ══════════════════════════════════════════════════════
// DEMO 1: Layout reutilizable con include
// Muestra cómo header.php y footer.php se insertan
// en esta página usando include.
// ══════════════════════════════════════════════════════

$titulo = 'Demo — Layout con include';

include __DIR__ . '/vistas/header.php';
?>

<div class="card shadow-sm p-4 mb-4 border-0" style="border-radius:15px">
    <h2 class="mb-3">
        <span class="badge" style="background:#8e44ad">include</span>
        Demo: Layout reutilizable
    </h2>
    <p class="lead">
        Esta página demuestra cómo dividir el HTML en partes reutilizables.
        El <strong>navbar</strong> y el <strong>footer</strong> que ves fueron insertados con <code>include</code>.
    </p>

    <hr>

    <h5>¿Qué ocurrió al cargar esta página?</h5>
    <ol>
        <li>PHP ejecutó <code>include __DIR__ . '/vistas/header.php'</code></li>
        <li>El contenido de <code>header.php</code> se insertó aquí.</li>
        <li>PHP renderizó el contenido principal (esta sección).</li>
        <li>PHP ejecutó <code>include __DIR__ . '/vistas/footer.php'</code></li>
        <li>El contenido de <code>footer.php</code> cerró la página.</li>
    </ol>

    <div class="alert alert-info mt-3">
        <strong><i class="fas fa-lightbulb me-2"></i>Dato:</strong>
        La variable <code>$titulo</code> definida antes del <code>include</code> es accesible
        dentro de <code>header.php</code>, por eso el título de esta pestaña del navegador
        dice <em>"<?= htmlspecialchars($titulo, ENT_QUOTES, 'UTF-8') ?>"</em>.
    </div>

    <h5 class="mt-4">Código de esta página</h5>
    <pre class="bg-dark text-light p-3 rounded"><code>&lt;?php
$titulo = 'Demo — Layout con include';

include __DIR__ . '/vistas/header.php';
?&gt;

&lt;!-- ...contenido principal... --&gt;

&lt;?php include __DIR__ . '/vistas/footer.php'; ?&gt;</code></pre>
</div>

<?php include __DIR__ . '/vistas/footer.php'; ?>
