<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($titulo ?? 'Demo Layout', ENT_QUOTES, 'UTF-8') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f4f7f6; font-family: 'Segoe UI', sans-serif; }
        .lab-badge { background: #8e44ad; color: white; padding: 2px 10px; border-radius: 20px; font-size: 0.75rem; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark shadow mb-4">
    <div class="container">
        <span class="navbar-brand fw-bold">
            ADSO <span class="text-info">PHP</span>
            <span class="lab-badge ms-2">Laboratorio</span>
        </span>
        <a href="../include_require.html" class="btn btn-sm btn-outline-light">← Volver a la teoría</a>
    </div>
</nav>
<div class="container">
