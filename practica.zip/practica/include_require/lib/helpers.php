<?php
// lib/helpers.php — funciones utilitarias reutilizables
// Este archivo es cargado con require_once para evitar redefiniciones

function limpiar(string $dato): string
{
    return htmlspecialchars(trim($dato), ENT_QUOTES, 'UTF-8');
}

function formatearFecha(string $fecha): string
{
    return date('d/m/Y', strtotime($fecha));
}

function saludar(string $nombre): string
{
    $hora = (int) date('H');
    $saludo = match(true) {
        $hora < 12 => 'Buenos días',
        $hora < 18 => 'Buenas tardes',
        default    => 'Buenas noches',
    };
    return "$saludo, " . limpiar($nombre) . "!";
}
