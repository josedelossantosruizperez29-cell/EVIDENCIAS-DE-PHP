<?php
// config/app.php
// Este archivo RETORNA un array de configuración.
// Se usa así: $config = include __DIR__ . '/config/app.php';

return [
    'nombre_app' => 'Mi Tienda PHP',
    'version'    => '1.0.0',
    'debug'      => true,
    'moneda'     => 'COP',
    'autor'      => 'ADSO 3066552',
    'fecha'      => date('Y'),
];
