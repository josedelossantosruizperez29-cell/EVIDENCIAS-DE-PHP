<?php
// ══════════════════════════════════════════════════════
// DEMO 3: require con archivo que NO existe
// Muestra que require emite un Fatal Error y DETIENE
// completamente la ejecución del script.
// ══════════════════════════════════════════════════════

ini_set('display_errors', '1');
error_reporting(E_ALL);

$titulo = 'Demo — require fallido (Fatal Error)';

include __DIR__ . '/vistas/header.php';
?>

<div class="card shadow-sm p-4 mb-4 border-0" style="border-radius:15px">
    <h2 class="mb-3">
        <span class="badge bg-danger">Fatal Error</span>
        Demo: <code>require</code> con archivo inexistente
    </h2>
    <p class="lead">
        Ahora se intentará hacer un <code>require</code> de un archivo que <strong>no existe</strong>.
        PHP emitirá un <strong>Fatal Error</strong> y <strong>todo lo que sigue no se ejecutará</strong>.
    </p>
    <hr>
    <div class="alert alert-danger">
        <strong><i class="fas fa-skull-crossbones me-2"></i>Después de esta línea, el script se detiene:</strong>
    </div>
<?php
// Este archivo NO existe → Fatal Error, se detiene todo
require __DIR__ . '/vistas/no_existe_critico.php';
?>

    <div class="alert alert-success">
        <strong>Este bloque NUNCA se mostrará</strong> porque el require anterior detuvo el script.
    </div>
</div>

<?php include __DIR__ . '/vistas/footer.php'; ?>
