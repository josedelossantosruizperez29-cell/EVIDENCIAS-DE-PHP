<?php
// ══════════════════════════════════════════════════════
// DEMO 2: include con archivo que NO existe
// Muestra que include emite un Warning pero el script
// CONTINÚA ejecutándose.
// ══════════════════════════════════════════════════════

ini_set('display_errors', '1');
error_reporting(E_ALL);

$titulo = 'Demo — include fallido (Warning)';

include __DIR__ . '/vistas/header.php';
?>

<div class="card shadow-sm p-4 mb-4 border-0" style="border-radius:15px">
    <h2 class="mb-3">
        <span class="badge bg-warning text-dark">Warning</span>
        Demo: <code>include</code> con archivo inexistente
    </h2>
    <p class="lead">
        Ahora se intentará incluir un archivo que <strong>no existe</strong>.
        Con <code>include</code>, PHP emitirá un <strong>Warning</strong> pero seguirá ejecutando el script.
    </p>
    <hr>
    <h5>⬇ Resultado del include fallido:</h5>
    <div class="border rounded p-3 bg-light">
<?php
// Este archivo NO existe → Warning, pero continúa
include __DIR__ . '/vistas/no_existe.php';
?>
    </div>

    <div class="alert alert-success mt-4">
        <strong><i class="fas fa-check-circle me-2"></i>¡El script siguió ejecutándose!</strong>
        Este texto aparece <em>después</em> del include fallido, demostrando que
        <code>include</code> no detiene la ejecución ante un archivo faltante.
    </div>

    <div class="alert alert-warning">
        <strong><i class="fas fa-exclamation-triangle me-2"></i>¿Cuándo usar esto?</strong>
        Solo cuando el archivo es verdaderamente <em>opcional</em>. En la mayoría de los casos
        es mejor usar <code>require</code> para detectar errores temprano.
    </div>

    <h5 class="mt-4">Código de este ejemplo</h5>
    <pre class="bg-dark text-light p-3 rounded"><code>&lt;?php
// Warning → continúa
include __DIR__ . '/vistas/no_existe.php';

echo "Este código SÍ se ejecuta después del Warning.";
?&gt;</code></pre>
</div>

<?php include __DIR__ . '/vistas/footer.php'; ?>
