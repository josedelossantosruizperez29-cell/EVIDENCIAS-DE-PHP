<?php
// ══════════════════════════════════════════════════════
// DEMO 5: include que retorna un valor
// Muestra cómo un archivo de configuración puede
// retornar un array y asignarlo a una variable.
// ══════════════════════════════════════════════════════

$titulo = 'Demo — include con return';

// include devuelve el valor retornado por el archivo incluido
$config = include __DIR__ . '/config/app.php';

include __DIR__ . '/vistas/header.php';
?>

<div class="card shadow-sm p-4 mb-4 border-0" style="border-radius:15px">
    <h2 class="mb-3">
        <span class="badge bg-secondary">return</span>
        Demo: <code>include</code> que retorna un valor
    </h2>
    <p class="lead">
        Un archivo incluido puede tener un <code>return</code>. El valor retornado se asigna
        a la variable que recibe el <code>include</code>. Es un patrón muy usado para archivos de configuración.
    </p>

    <hr>

    <h5>Contenido de <code>config/app.php</code> (retorna este array):</h5>
    <pre class="bg-dark text-light p-3 rounded"><code>&lt;?php
return [
    'nombre_app' =&gt; 'Mi Tienda PHP',
    'version'    =&gt; '1.0.0',
    'debug'      =&gt; true,
    'moneda'     =&gt; 'COP',
    'autor'      =&gt; 'ADSO 3066552',
    'fecha'      =&gt; date('Y'),
];</code></pre>

    <h5 class="mt-4">Código de carga:</h5>
    <pre class="bg-dark text-light p-3 rounded"><code>$config = include __DIR__ . '/config/app.php';</code></pre>

    <h5 class="mt-4">Valores cargados en <code>$config</code>:</h5>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Clave</th>
                <th>Valor</th>
                <th>Tipo</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($config as $clave => $valor): ?>
            <tr>
                <td><code><?= htmlspecialchars($clave, ENT_QUOTES, 'UTF-8') ?></code></td>
                <td>
                    <?php if (is_bool($valor)): ?>
                        <span class="badge <?= $valor ? 'bg-success' : 'bg-secondary' ?>">
                            <?= $valor ? 'true' : 'false' ?>
                        </span>
                    <?php else: ?>
                        <code><?= htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8') ?></code>
                    <?php endif; ?>
                </td>
                <td><span class="badge bg-secondary"><?= gettype($valor) ?></span></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="alert alert-info mt-3">
        <strong><i class="fas fa-info-circle me-2"></i>¿Por qué no usar <code>require_once</code> aquí?</strong><br>
        Con <code>require_once</code> no podrías capturar el valor retornado la segunda vez que se cargue el archivo,
        porque PHP lo omite. Para archivos de configuración que se cargan una sola vez, <code>require</code> o
        <code>include</code> son suficientes. Muchos frameworks como Laravel usan exactamente este patrón.
    </div>
</div>

<?php include __DIR__ . '/vistas/footer.php'; ?>
