<?php
// =============================================================
// PASO 1: Archivo de configuración central
// =============================================================
// Este archivo define las constantes globales del blog.
// No debe imprimir nada (ni HTML, ni echo).
// Se cargará con require_once desde index.php y receta.php.
// =============================================================

// TODO 1: Define la constante BLOG_TITULO con el nombre de tu blog (string)
//         Ejemplo: 'Recetas de Mamá'
define('BLOG_TITULO', 'Recetas de Mamá');

// TODO 2: Define la constante BLOG_AUTOR con tu nombre completo (string)
define('BLOG_AUTOR', 'José de los Santos');

// TODO 3: Define la constante BLOG_ANIO con el año actual como número entero
//         Pista: date('Y') devuelve el año actual como string, puedes convertirlo.
define('BLOG_ANIO', 2026);

// TODO 4: Define la constante RECETAS_POR_PAGINA con el valor 5 (entero)
define('RECETAS_POR_PAGINA', 5);
