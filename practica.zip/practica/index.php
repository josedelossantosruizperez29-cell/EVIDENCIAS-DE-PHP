<?php
require_once __DIR__ . '/index_practica.php';
