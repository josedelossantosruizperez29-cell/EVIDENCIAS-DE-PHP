<?php
// =============================================================
// PASO 6: Página de detalle de una receta
// =============================================================

require_once __DIR__ . '/config/app.php';

require_once __DIR__ . '/lib/helpers.php';

// ── Catálogo completo de recetas ──────────────────────────────
$catalogo = [
    'arroz-leche' => [
        'nombre'       => 'Arroz con leche',
        'categoria'    => 'Postres',
        'fecha'        => '2026-03-15',
        'descripcion'  => 'Un postre clásico cremoso con leche, arroz, canela y azúcar morena. Perfecto para el frío.',
        'ingredientes' => ['1 taza de arroz', '1 litro de leche', '1 astilla de canela', 'Azúcar al gusto'],
    ],
    'ajiaco' => [
        'nombre'       => 'Ajiaco bogotano',
        'categoria'    => 'Sopas',
        'fecha'        => '2026-03-20',
        'descripcion'  => 'Sopa tradicional colombiana con tres tipos de papas, pollo y guasca. Símbolo de Bogotá.',
        'ingredientes' => ['Papa criolla', 'Papa pastusa', 'Papa sabanera', 'Pechuga de pollo', 'Guasca'],
    ],
    'bandeja-paisa' => [
        'nombre'       => 'Bandeja paisa',
        'categoria'    => 'Platos fuertes',
        'fecha'        => '2026-04-01',
        'descripcion'  => 'El plato insignia de la región antioqueña: frijoles, carne molida, chicharrón y más.',
        'ingredientes' => ['Frijoles rojos', 'Carne molida', 'Chicharrón', 'Arroz blanco', 'Huevo frito', 'Aguacate'],
    ],
    'empanadas' => [
        'nombre'       => 'Empanadas de pipián',
        'categoria'    => 'Snacks',
        'fecha'        => '2026-04-03',
        'descripcion'  => 'Empanadas fritas de masa de maíz rellenas de papa y hogao, con salsa de maní.',
        'ingredientes' => ['Masa de maíz', 'Papa', 'Hogao', 'Maní tostado'],
    ],
];

// ── Validar el id recibido ────────────────────────────────────

$id = $_GET['id'] ?? '';

if (!array_key_exists($id, $catalogo)) {
    header('Location: index.php');
    exit;
}

$receta = $catalogo[$id];
$titulo = $receta['nombre'];

include __DIR__ . '/vistas/header.php';
?>

<a href="index.php" class="btn btn-outline-secondary btn-sm mb-4">
    &larr; Volver a todas las recetas
</a>

<div class="card shadow-sm p-4">

    <span class="badge bg-secondary mb-2 d-inline-block" style="width:fit-content">
        <?= esc($receta['categoria']) ?>
    </span>

    <h1 class="mt-1"><?= esc($receta['nombre']) ?></h1>

    <p class="text-muted">
        <i class="fas fa-calendar me-1"></i>
        <?= formatearFecha($receta['fecha']) ?>
    </p>

    <p class="lead mt-3"><?= esc($receta['descripcion']) ?></p>

    <h5 class="mt-4">
        <i class="fas fa-list me-2"></i>Ingredientes
    </h5>
    <ul class="list-group list-group-flush">
    <?php foreach ($receta['ingredientes'] as $ing): ?>
        <li class="list-group-item"><?= esc($ing) ?></li>
    <?php endforeach; ?>
    </ul>

</div>

<?php
include __DIR__ . '/vistas/footer.php';
?>
